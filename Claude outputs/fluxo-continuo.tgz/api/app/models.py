from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import relationship

from .db import Base


class Channel(Base):
    __tablename__ = "channels"

    id = Column(Integer, primary_key=True)
    tvg_id = Column(String(255), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    logo_url = Column(String(500))
    backdrop_url = Column(String(600))
    description = Column(Text)
    category = Column(String(50), index=True)
    language = Column(String(8), index=True)
    is_broadcast_tv = Column(Boolean, nullable=False, default=False)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    streams = relationship("Stream", back_populates="channel", cascade="all, delete-orphan")


class Stream(Base):
    __tablename__ = "streams"

    id = Column(Integer, primary_key=True)
    channel_id = Column(Integer, ForeignKey("channels.id", ondelete="CASCADE"), nullable=False)
    url = Column(String(4000), nullable=False)
    referrer = Column(String(500))
    user_agent = Column(String(500))
    quality = Column(String(20))
    # idioma do stream (vem do feeds.json do iptv-org): "Português",
    # "Legendado", "Japonês", "Inglês"... NULL = tratado como "Português" no
    # frontend (canal de país lusófono cujo feed não trouxe idioma). feed_id é
    # o id do feed no iptv-org, guardado só pra rastrear a origem.
    feed_id = Column(String(60))
    lang_label = Column(String(40))
    is_healthy = Column(Boolean, index=True)
    consecutive_failures = Column(Integer, nullable=False, default=0)
    last_checked_at = Column(DateTime)
    # reportado pelo NAVEGADOR do usuário quando o player falha de verdade, mesmo
    # depois do /resolve ter aprovado — sinal mais forte que qualquer checagem
    # server-side, porque reflete o que o cliente real conseguiu (ou não) tocar.
    # Ver ARQUITETURA.md secao 8.2.
    client_failed_at = Column(DateTime)
    client_failure_count = Column(Integer, nullable=False, default=0)
    # "Validar fluxo continuo" (migration 011): True = o stream entregou dados
    # de forma continua (TS bruto) / segmentos de verdade (HLS); False = parou,
    # travou ou so deu o inicio; NULL = nunca testado ou resultado inconclusivo
    flow_ok = Column(Boolean)
    flow_checked_at = Column(DateTime)
    flow_note = Column(String(160))
    created_at = Column(DateTime, server_default=func.now())

    channel = relationship("Channel", back_populates="streams")


class Program(Base):
    __tablename__ = "programs"

    id = Column(Integer, primary_key=True)
    channel_id = Column(Integer, ForeignKey("channels.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(500), nullable=False)
    subtitle = Column(String(500))
    description = Column(Text)
    category = Column(String(200))
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    created_at = Column(DateTime, server_default=func.now())


class VodTitle(Base):
    """Catálogo sob demanda (filmes/séries) — fica vazio até você adicionar
    títulos/links manualmente, conforme for conseguindo autorização pra cada
    obra. Nunca é populado automaticamente por nenhum worker. Ver
    ARQUITETURA.md seção 10."""

    __tablename__ = "vod_titles"

    id = Column(Integer, primary_key=True)
    type = Column(String(10), nullable=False)  # "movie" ou "series"
    title = Column(String(500), nullable=False)
    description = Column(Text)
    poster_url = Column(String(500))
    backdrop_url = Column(String(600))
    genre = Column(String(100))
    language = Column(String(8), index=True)
    year = Column(Integer)
    rating = Column(Float)  # nota média do TMDB (0-10)
    tmdb_id = Column(Integer)  # id do TMDB (pra futuras consultas de detalhe)
    created_at = Column(DateTime, server_default=func.now())

    items = relationship("VodItem", back_populates="vod_title", cascade="all, delete-orphan")


class VodItem(Base):
    """Um item reproduzível: pra filme, 1 item por título (season/episode nulos);
    pra série, 1 item por episódio. `stream_url` fica NULL até você preencher —
    é o que marca o item como disponível ou não."""

    __tablename__ = "vod_items"

    id = Column(Integer, primary_key=True)
    title_id = Column(Integer, ForeignKey("vod_titles.id", ondelete="CASCADE"), nullable=False)
    season_number = Column(Integer)
    episode_number = Column(Integer)
    episode_title = Column(String(500))
    stream_url = Column(String(4000))
    created_at = Column(DateTime, server_default=func.now())

    # espelham as colunas equivalentes de Stream (canais ao vivo) — o
    # health-check manual/automático testa VOD junto com TV ao vivo agora
    is_healthy = Column(Boolean)
    consecutive_failures = Column(Integer, nullable=False, server_default="0")
    last_checked_at = Column(DateTime)

    vod_title = relationship("VodTitle", back_populates="items")
    streams = relationship("VodStream", back_populates="item", cascade="all, delete-orphan")


class VodStream(Base):
    """Mirror de um VodItem — mesmo papel que `Stream` tem pra `Channel`: mais
    de um link por filme/episódio, health-check e fallback independentes por
    link. `VodItem.stream_url` continua existindo só como cache do melhor
    mirror atual (pra não quebrar quem lê esse campo direto); a fonte de
    verdade pra ranking/fallback é esta tabela."""

    __tablename__ = "vod_streams"

    id = Column(Integer, primary_key=True)
    item_id = Column(Integer, ForeignKey("vod_items.id", ondelete="CASCADE"), nullable=False)
    url = Column(String(4000), nullable=False)
    is_healthy = Column(Boolean)
    consecutive_failures = Column(Integer, nullable=False, default=0)
    last_checked_at = Column(DateTime)
    client_failed_at = Column(DateTime)
    client_failure_count = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, server_default=func.now())

    item = relationship("VodItem", back_populates="streams")


class WatchProgress(Base):
    """"Continuar assistindo": 1 linha por (token, título). Guarda a posição do
    filme ou do episódio atual da série. Quando o título/episódio é assistido
    até o fim, a linha é removida (ou avança pro próximo episódio, se houver)."""

    __tablename__ = "watch_progress"

    id = Column(Integer, primary_key=True)
    token_id = Column(Integer, ForeignKey("access_tokens.id", ondelete="CASCADE"), nullable=False)
    title_id = Column(Integer, ForeignKey("vod_titles.id", ondelete="CASCADE"), nullable=False)
    item_id = Column(Integer, ForeignKey("vod_items.id", ondelete="SET NULL"))  # episódio; NULL p/ filme
    position = Column(Float, nullable=False, default=0)
    duration = Column(Float)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (UniqueConstraint("token_id", "title_id", name="uq_watch_token_title"),)


class AdminUser(Base):
    """Login do site — TODO acesso passa por aqui agora, não só o painel
    admin. `role` decide o que a conta vê: "admin" (lista + painel completo)
    ou "user" (só a lista, via o AccessToken em `access_token_id`)."""

    __tablename__ = "admin_users"

    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    # cadastro feito só pelo admin (menu Usuários): nome de exibição e e-mail
    name = Column(String(150))
    email = Column(String(255))
    role = Column(String(20), nullable=False, default="admin", server_default="admin")
    access_token_id = Column(Integer, ForeignKey("access_tokens.id", ondelete="SET NULL"))
    created_at = Column(DateTime, server_default=func.now())

    access_token = relationship("AccessToken")

    # mesmo nome da migration 008 (assim o create_all e a migration não duplicam o índice)
    __table_args__ = (Index("uq_admin_users_email", "email", unique=True),)


class AdminSession(Base):
    __tablename__ = "admin_sessions"

    id = Column(Integer, primary_key=True)
    session_token = Column(String(64), unique=True, nullable=False)
    admin_user_id = Column(Integer, ForeignKey("admin_users.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    expires_at = Column(DateTime, nullable=False)
    # sessão criada pelo bilhete do play.exposite.com.br (HTTP): sem poder de admin
    play_only = Column(Boolean, nullable=False, default=False, server_default="0")


class ImportSource(Base):
    """Fonte de canais (lista M3U) que o admin gerencia na página "Importar fontes".

    origin: preset (iptv-org/Free-TV, já sincronizada alguma vez), custom (URL
    colada pelo admin) ou github (achada na busca do GitHub).
    status: approved (pode sincronizar) ou pending (candidata do GitHub
    esperando o admin aprovar -- nada é importado antes disso)."""

    __tablename__ = "import_sources"
    __table_args__ = (Index("uq_import_sources_url", "url", unique=True),)

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    url = Column(String(500), nullable=False)
    origin = Column(String(20), nullable=False, default="custom")
    status = Column(String(20), nullable=False, default="approved")
    last_sync_at = Column(DateTime)
    last_status = Column(String(20))  # done | error | running
    last_summary = Column(Text)  # JSON com os números da última sincronização
    created_at = Column(DateTime, server_default=func.now())


class WorkerRun(Base):
    """1 linha por job do worker (fetch_channels/healthcheck/fetch_epg), sempre
    atualizada — última execução de cada um, pro dashboard."""

    __tablename__ = "worker_runs"

    job_name = Column(String(50), primary_key=True)
    last_run_at = Column(DateTime, nullable=False)
    status = Column(String(20), nullable=False)
    summary = Column(String(500))
    duration_seconds = Column(Integer)


class GenreKeyword(Base):
    """Palavra/expressão (EN ou PT) que indica um gênero, usada pra classificar
    títulos VOD sem gênero automaticamente por palavra-chave no título. Editável
    via /genres.html. A ordem de prioridade na classificação é pelo `id` mais
    antigo de cada gênero (gênero "descoberto" primeiro = checado primeiro)."""

    __tablename__ = "genre_keywords"

    id = Column(Integer, primary_key=True)
    genre = Column(String(100), nullable=False, index=True)
    keyword = Column(String(200), nullable=False)
    created_at = Column(DateTime, server_default=func.now())


class AccessToken(Base):
    __tablename__ = "access_tokens"

    id = Column(Integer, primary_key=True)
    token = Column(String(64), unique=True, nullable=False)
    label = Column(String(100))
    is_active = Column(Boolean, nullable=False, default=True)
    # controla se esse token vê conteúdo com category/genre = "Adulto" (canais,
    # filmes, séries, animes) -- padrão False, o admin liga manualmente só pro
    # token que ele mesmo usa (ver ADULT_GENRE/ADULT_CATEGORY nos routers)
    sees_adult_content = Column(Boolean, nullable=False, default=False)
    # tipos de conteúdo liberados: "live,movie,series,anime" (ver content_access.py).
    # NULL = tudo liberado
    content_types = Column(String(100))
    created_at = Column(DateTime, server_default=func.now())
    last_used_at = Column(DateTime)
